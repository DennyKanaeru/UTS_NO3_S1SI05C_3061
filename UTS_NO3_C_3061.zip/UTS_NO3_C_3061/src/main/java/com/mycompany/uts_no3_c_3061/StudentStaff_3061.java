/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.uts_no3_c_3061;

/**
 *
 * @author badnoby
 */
public class StudentStaff_3061 extends Mahasiswa_3061 {
    int jamKerja_3061;
    String unitKerja_3061;
    
    public double totalPendapatan_3061(){
        return (jamKerja_3061 * 30000);
    }
    public void tampilDataStudentStaff_3061(){
        super.tampilDataMhs_3061();
        System.out.println(" Unit Kerja : " + unitKerja_3061);
        System.out.println(" Jam Kerja : " +jamKerja_3061);
        System.out.println(" Total Pendapatan Student Staff : " +totalPendapatan_3061());
    }
}
