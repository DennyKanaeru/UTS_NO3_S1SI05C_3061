/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.mycompany.uts_no3_c_3061;

/**
 *
 * @author badnoby
 */
public interface Pendapatan_3061 {
    public double totalPendapatan_3061 ();
}
