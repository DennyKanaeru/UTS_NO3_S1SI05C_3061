/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.uts_no3_c_3061;

import java.io.BufferedReader;
import java.io.InputStreamReader;

/**
 *
 * @author badnoby
 */
public class UTS_NO3_C_3061 {

    public static void main(String[] args) {
        //Membuat object menggunakan array
        AsistenPraktikum_3061[] AsPrak_3061 = new AsistenPraktikum_3061[1];
        StudentStaff_3061[] StuStaff_3061 = new StudentStaff_3061[1];
        
        AsPrak_3061[0] = new AsistenPraktikum_3061();
        StuStaff_3061[0] = new StudentStaff_3061();

        //program input menggunakan buffered reader
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
         
        try {
            //mengisi data ke array pada data nelayan
            for(int i = 0; i < 1; i++){
                System.out.print("NIM              : ");
                AsPrak_3061[i].nim_3061 = br.readLine();
                System.out.print("Nama             : ");
                AsPrak_3061[i].nama_3061 = br.readLine();
                System.out.print("Jurusan          : ");
                AsPrak_3061[i].jurusan_3061 =br.readLine();
                System.out.print("IPK              : ");
                AsPrak_3061[i].ipk_3061 =Integer.parseInt(br.readLine());
                System.out.print("Mata Kuliah      : ");
                AsPrak_3061[i].mkAsisten_3061 = br.readLine();
                System.out.print("Jumlah Pertemuan : ");
                AsPrak_3061[i].jmlPertemuan_3061 = Integer.parseInt(br.readLine());
                System.out.println();
            }
            
            //Menampilkan semua isi array pada data nelayan
            System.out.println("DATA ASISTEN PRAKTIKUM");
            for(AsistenPraktikum_3061 AP : AsPrak_3061){
                AP.tampilDataAsistenPraktikum_3061();
                System.out.println("");
            }

            //mengisi data ke array pada data dokter
            for(int i = 0; i < 1; i++){
                System.out.print("NIM         : ");
                StuStaff_3061[i].nim_3061 = br.readLine();
                System.out.print("Nama        : ");
                StuStaff_3061[i].nama_3061 = br.readLine();
                System.out.print("Jurusan     : ");
                StuStaff_3061[i].jurusan_3061 =br.readLine();
                System.out.print("IPK         : ");
                StuStaff_3061[i].ipk_3061 =Integer.parseInt(br.readLine());
                System.out.print(" Unit Kerja : ");
                StuStaff_3061[i].unitKerja_3061 = br.readLine();
                System.out.print("Jam Kerja   : ");
                StuStaff_3061[i].jamKerja_3061 = Integer.parseInt(br.readLine());
                System.out.println();
            }
            
            //Menampilkan semua isi array pada data dokter
            System.out.println("DATA STUDENT STAFF");
            for(StudentStaff_3061 SS : StuStaff_3061){
                SS.tampilDataStudentStaff_3061();
                System.out.println("");
            }
        } 
        catch (Exception ex){ // menangkap kesalahan
            System.out.println(ex);
        }
    }
}
