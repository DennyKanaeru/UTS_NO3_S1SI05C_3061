/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.uts_no3_c_3061;

/**
 *
 * @author badnoby
 */
import java.io.BufferedReader;
public class Mahasiswa_3061 {
    String nim_3061, nama_3061, jurusan_3061;
    int ipk_3061;
    
    public void tampilDataMhs_3061() {
        System.out.println(" NIM    : " + nim_3061);
        System.out.println("Nama    " + nama_3061);
        System.out.println("Jurusan    : " + jurusan_3061);
        System.out.println("IPK : " + ipk_3061);
    }
}
